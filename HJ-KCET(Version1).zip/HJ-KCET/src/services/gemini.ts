import { GoogleGenerativeAI } from '@google/generative-ai';
import type { CollegeData, UserInput } from '../types';

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

export async function getPredictions(collegeData: CollegeData[], userInput: UserInput) {
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

  const prompt = `
    Given a student's KCET rank of ${userInput.rank}, preferred locations: ${userInput.locations.join(', ')}, 
    and category: ${userInput.category}, analyze the following college data and provide recommendations.
    
    Consider:
    1. Colleges where the cutoff rank is higher than the student's rank
    2. Preferred locations
    3. Previous year trends
    4. Branch opportunities
    
    Please provide:
    1. Top college recommendations
    2. Suggested option entry strategy
    3. Alternative options to consider
    
    College data: ${JSON.stringify(collegeData)}
  `;

  const result = await model.generateContent(prompt);
  const response = await result.response;
  return response.text();
}

export async function getChatbotResponse(message: string, collegeData: CollegeData[]) {
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

  const prompt = `
    You are a KCET counseling assistant. Help students with college and branch selection based on their ranks.
    Use this college data for reference: ${JSON.stringify(collegeData)}
    
    Student question: ${message}
    
    Provide a helpful, accurate response based on the data.
  `;

  const result = await model.generateContent(prompt);
  const response = await result.response;
  return response.text();
}
