import React, { useState } from 'react';
import { Search, MapPin, Users } from 'lucide-react';

interface PredictionFormProps {
  onSubmit: (data: { rank: number; locations: string[]; category: string }) => void;
}

const categories = [
  'GM', '1G', '2AG', '2BG', '3AG', '3BG', 'SCG', 'STG'
];

export function PredictionForm({ onSubmit }: PredictionFormProps) {
  const [rank, setRank] = useState('');
  const [locations, setLocations] = useState(['', '', '']);
  const [category, setCategory] = useState('GM');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      rank: parseInt(rank),
      locations: locations.filter(l => l.trim() !== ''),
      category
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow-md">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          KCET Rank
        </label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="number"
            required
            value={rank}
            onChange={(e) => setRank(e.target.value)}
            className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
            placeholder="Enter your rank"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Preferred Locations (in order)
        </label>
        <div className="space-y-2">
          {locations.map((location, index) => (
            <div key={index} className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MapPin className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={location}
                onChange={(e) => {
                  const newLocations = [...locations];
                  newLocations[index] = e.target.value;
                  setLocations(newLocations);
                }}
                className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
                placeholder={`Preferred location ${index + 1}`}
              />
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Category
        </label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Users className="h-5 w-5 text-gray-400" />
          </div>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 sm:text-sm border-gray-300 rounded-md"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
      >
        Get Predictions
      </button>
    </form>
  );
}