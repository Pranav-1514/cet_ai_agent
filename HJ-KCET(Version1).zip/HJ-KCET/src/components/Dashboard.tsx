import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { GraduationCap, MapPin, BookOpen } from 'lucide-react';
import type { CollegeData } from '../types';
import ReactMarkdown from 'react-markdown';

interface DashboardProps {
  predictions: CollegeData[];
  aiSuggestions: string;
}

export function Dashboard({ predictions, aiSuggestions }: DashboardProps) {
  const topColleges = predictions.slice(0, 5);

  const chartData = topColleges.map(college => ({
    name: college.College.split(' ').slice(0, 3).join(' '),
    'Previous Cutoff': parseInt(college.GM || '0', 10), // Fix: Correct property access
  }));  

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <GraduationCap className="h-8 w-8 text-indigo-600" />
            <h3 className="ml-3 text-lg font-medium text-gray-900">Top Matches</h3>
          </div>
          <p className="mt-2 text-sm text-gray-500">
            Based on your rank and preferences
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <MapPin className="h-8 w-8 text-green-600" />
            <h3 className="ml-3 text-lg font-medium text-gray-900">Location Match</h3>
          </div>
          <p className="mt-2 text-sm text-gray-500">
            Colleges in your preferred locations
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center">
            <BookOpen className="h-8 w-8 text-purple-600" />
            <h3 className="ml-3 text-lg font-medium text-gray-900">Branch Options</h3>
          </div>
          <p className="mt-2 text-sm text-gray-500">
            Available branches based on cutoff
          </p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Cutoff Comparison</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Previous Cutoff" fill="#4f46e5" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Detailed College List</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">College</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Branch</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Previous Cutoff</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {predictions.map((college, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{college.College}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{college.Branch}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{college.Location}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{college.GM}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-medium text-gray-900 mb-4">AI Recommendations</h3>
        
        <div className="prose max-w-none text-gray-700">
          <ReactMarkdown>{aiSuggestions}</ReactMarkdown>
        </div>
      </div>
    </div>
  );
}