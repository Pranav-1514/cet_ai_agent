import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';
import { PredictionForm } from './components/PredictionForm';
import { Dashboard } from './components/Dashboard';
import { Chatbot } from './components/Chatbot';
import { getPredictions, getChatbotResponse } from './services/gemini';
import type { CollegeData } from './types';

function App() {
  const [collegeData, setCollegeData] = useState<CollegeData[]>([]);
  const [predictions, setPredictions] = useState<CollegeData[]>([]);
  const [aiSuggestions, setAiSuggestions] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Load CSV data
    fetch('/data/kcet_data.csv')
      .then(response => response.text())
      .then(csv => {
        const results = Papa.parse<CollegeData>(csv, { header: true });
        setCollegeData(results.data.filter(row => row.CETCode && row.College));
      });
  }, []);

  const handleFormSubmit = async (data: { rank: number; locations: string[]; category: string }) => {
    setLoading(true);
    try {
      // Filter colleges based on rank and location
      const filteredColleges = collegeData.filter(college => {
        const cutoff = parseInt(college[data.category] || '0');
        return (
          cutoff >= data.rank &&
          (data.locations.length === 0 || data.locations.some(loc => 
            college.Location.toLowerCase().includes(loc.toLowerCase())
          ))
        );
      });

      setPredictions(filteredColleges);

      // Get AI suggestions
      const suggestions = await getPredictions(filteredColleges, {
        rank: data.rank,
        locations: data.locations,
        category: data.category
      });
      setAiSuggestions(suggestions);
    } catch (error) {
      console.error('Error getting predictions:', error);
    }
    setLoading(false);
  };

  const handleChatMessage = async (message: string) => {
    return await getChatbotResponse(message, collegeData);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <h1 className="text-3xl font-bold-mono text-gray-900 mb-8"><b>KCET COLLEGE PREDICTOR</b></h1>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <PredictionForm onSubmit={handleFormSubmit} />
              <div className="mt-8">
                <Chatbot onSendMessage={handleChatMessage} />
              </div>
            </div>
            
            <div className="lg:col-span-2">
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
                </div>
              ) : predictions.length > 0 ? (
                <Dashboard predictions={predictions} aiSuggestions={aiSuggestions} />
              ) : (
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <h2 className="text-xl font-medium text-gray-900">Welcome to KCET College Predictor</h2>
                  <p className="mt-2 text-gray-500">
                    Enter your rank, preferred locations, and category to get personalized college predictions.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;